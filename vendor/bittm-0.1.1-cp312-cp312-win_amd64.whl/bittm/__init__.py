"""bittm: fast, interpretable Tsetlin Machines with bit-packed training and inference."""
from ._version import __version__
from .booleanize import Booleanizer, QuantileBooleanizer
from .model import PackedModel, Rule, load
from .tm import CoalescedTsetlinMachine, TsetlinMachine

__all__ = ["Booleanizer", "CoalescedTsetlinMachine", "PackedModel", "QuantileBooleanizer", "Rule", "TsetlinMachine",
           "__version__", "load"]
