import time

import numpy as np

from . import _core
from ._compat import BaseEstimator, ClassifierMixin
from .model import PackedModel


class TsetlinMachine(ClassifierMixin, BaseEstimator):
    """Vanilla multiclass Tsetlin Machine (Granmo 2018) trained by the C++ core.

    Each class owns ``clauses_per_class`` clauses; the first half vote for the class, the second half against.
    Training evaluates clauses with a bitmask per clause; inference goes through :class:`PackedModel`.

    clauses_per_class: even number of clauses per class.
    T: vote threshold; limits how many clauses may learn one pattern.
    s: specificity (>= 1.0). Small s forms short clauses; s = 1.0 gives reasoning by elimination.
    boost_true_positive: always reward true literals of a firing clause in Type I feedback.
    n_states: automaton states per action (1..127). A literal is included when its state exceeds n_states.
    weighted: give every clause an integer weight (>= 1) learned by feedback; its vote is weight * output.
        Votes become larger, so T usually needs to be larger too.
    literal_budget: soft limit on literals per clause (None = no limit). As in Green Tsetlin, a clause with more
        literals than this still votes, but training treats it as not firing, which removes literals until it fits.
        So clauses are pushed toward short rules; a few may be over the limit at any moment.
    epochs: training passes per ``fit`` call (a constructor parameter so GridSearchCV can tune it).
    class_weight: None, ``"balanced"`` (rows of rare classes count more: n / (n_classes * class count)) or a dict
        ``{label: weight}`` (labels not listed get 1.0). Works together with ``sample_weight`` in ``fit``; see
        :meth:`fit` for how weights act on training.

    ``fit`` starts from scratch each time (scikit-learn convention); ``partial_fit`` continues training.
    """

    def __init__(self, clauses_per_class=100, T=50, s=3.0, boost_true_positive=False, n_states=100, weighted=False,
                 literal_budget=None, random_state=0, epochs=10, class_weight=None):
        self.class_weight = class_weight
        self.weighted = weighted
        self.literal_budget = literal_budget
        self.clauses_per_class = clauses_per_class
        self.T = T
        self.s = s
        self.boost_true_positive = boost_true_positive
        self.n_states = n_states
        self.random_state = random_state
        self.epochs = epochs
        self._validate()
        self._reset()

    def _validate(self):
        if self.clauses_per_class < 2 or self.clauses_per_class % 2:
            raise ValueError("clauses_per_class must be even and >= 2")
        self._check_T()
        self._check_s()
        if not 1 <= self.n_states <= 127:
            raise ValueError("n_states must be in [1, 127]")
        if self.literal_budget is not None and self.literal_budget < 1:
            raise ValueError("literal_budget must be >= 1 or None")
        if self.epochs < 0:
            raise ValueError("epochs must be >= 0")
        cw = self.class_weight
        if not (cw is None or isinstance(cw, dict) or (isinstance(cw, str) and cw == "balanced")):
            raise ValueError('class_weight must be None, "balanced" or a dict {label: weight}')

    def _check_T(self):
        if isinstance(self.T, str) or self.T < 1:
            raise ValueError("T must be an integer >= 1")

    def _check_s(self):
        if isinstance(self.s, str) or self.s < 1.0:
            raise ValueError("s must be >= 1.0")

    def _after_epoch(self, record):
        """Hook called after every training epoch (the coalesced machine adapts T here)."""

    @property
    def T_(self):
        """The threshold in use (equals ``T`` unless the machine chooses it itself)."""
        return self.T

    @property
    def s_(self):
        """The specificity in use (equals ``s`` unless the machine chooses it itself)."""
        return float(self.s)

    def _reset(self):
        self.classes_ = None
        self.history_ = []
        self.best_val_accuracy_ = None  # set when fit gets X_val / y_val
        self.best_epoch_ = None
        self.best_model_ = None  # PackedModel of the best validation epoch
        self._core = None
        self._packed = None
        self._calibration = None  # set by calibrate()

    # -- helpers -------------------------------------------------------------------------------
    @staticmethod
    def _bits(X):
        X = np.asarray(X)
        if X.ndim != 2:
            raise ValueError("X must be 2-dimensional")
        if X.size and X.dtype != bool:
            # max() is one fast pass for unsigned ints; other types need an explicit 0/1 test
            ok = X.max() <= 1 if X.dtype.kind == "u" else ((X == 0) | (X == 1)).all()
            if not ok:
                raise ValueError("X must contain only 0 and 1 (see Booleanizer)")
        return np.ascontiguousarray(X, dtype=np.uint8)

    def _class_weight_array(self, y, classes):
        """Weight per class (aligned with the sorted ``classes``), or None when ``class_weight`` is None."""
        cw = self.class_weight
        if cw is None:
            return None
        classes = np.unique(classes)
        if isinstance(cw, str):
            counts = np.array([(y == c).sum() for c in classes], dtype=np.float64)
            if (counts == 0).any():
                raise ValueError('class_weight="balanced" needs every class to appear in y; pass a dict instead')
            return len(y) / (len(classes) * counts)
        known = set(classes.tolist())
        unknown = [k for k in cw if k not in known]
        if unknown:
            raise ValueError("class_weight has labels that are not in y: %r" % (unknown,))
        out = np.array([float(cw.get(c, 1.0)) for c in classes])
        if (out < 0).any() or not np.isfinite(out).all():
            raise ValueError("class_weight values must be finite and >= 0")
        return out

    def _row_weights(self, y, classes, sample_weight):
        """(row weights or None, per-class weights or None) from ``sample_weight`` and ``class_weight``."""
        cw = self._class_weight_array(y, classes)
        w = None
        if sample_weight is not None:
            w = np.asarray(sample_weight, dtype=np.float64)
            if w.ndim != 1 or len(w) != len(y):
                raise ValueError("sample_weight must be 1-dimensional with one value per row of X")
            if not np.isfinite(w).all() or (w < 0).any():
                raise ValueError("sample_weight must be finite and >= 0")
        if cw is not None:
            by_class = cw[np.searchsorted(np.unique(classes), y)]
            w = by_class if w is None else w * by_class
        if w is not None and not w.sum() > 0:
            raise ValueError("the weights sum to zero, so there is nothing to learn from")
        return w, cw

    def _init(self, X, y, classes=None, feature_names=None):
        self._validate()
        self.classes_ = np.unique(y if classes is None else classes)
        if len(self.classes_) < 2:
            raise ValueError("need at least two classes")
        self.n_features_ = self.n_features_in_ = X.shape[1]
        if feature_names is not None:
            self.feature_names_in_ = feature_names
        elif hasattr(self, "feature_names_in_"):
            del self.feature_names_in_
        self._core = self._make_core()

    def _make_core(self):
        return _core.Trainer(self.n_features_, len(self.classes_), self.clauses_per_class, self.T, float(self.s),
                             self.boost_true_positive, self.n_states, bool(self.weighted),
                             int(self.literal_budget or 0), int(self.random_state))

    def _vote_weights(self):
        """(n_clauses, n_classes) int32 matrix: what each clause adds to each class when it fires."""
        n_clauses = self._core.n_clauses
        cpc = self.clauses_per_class
        j = np.arange(n_clauses)
        weights = np.zeros((n_clauses, len(self.classes_)), dtype=np.int32)
        weights[j, j // cpc] = np.where((j % cpc) < cpc // 2, 1, -1) * self.weights_
        return weights

    def _encode(self, y):
        y = np.asarray(y)
        idx = np.searchsorted(self.classes_, y)
        if (idx >= len(self.classes_)).any() or (self.classes_[np.minimum(idx, len(self.classes_) - 1)] != y).any():
            raise ValueError("y contains a label that was not present in the first call to fit")
        return np.ascontiguousarray(idx, dtype=np.int32)

    # -- training ------------------------------------------------------------------------------
    def fit(self, X, y, epochs=None, shuffle=True, X_val=None, y_val=None, verbose=False, sample_weight=None):
        """Train from scratch for ``epochs`` passes (default: the ``epochs`` parameter).

        X_val / y_val: score after every epoch and keep the best epoch in ``best_model_``.
        sample_weight: one non-negative number per row (combined with ``class_weight`` by multiplying). A weight
            sets how often a row is used: every epoch, a row with weight w is used floor(w') times plus once more
            with probability w' - floor(w'), where w' = w * n / sum(w) (so an epoch still has about n rows and a
            weight of 0 drops the row). Validation accuracy is weighted by ``class_weight`` (and, for rows held back
            from the training data, by ``sample_weight``), so the best epoch is chosen for the weighted goal.
        """
        self._reset()
        y = np.asarray(y)
        w, cw = self._row_weights(y, y, sample_weight)
        val_w = self._val_weights(cw, y, y_val)
        return self._train(X, y, None, self.epochs if epochs is None else epochs, shuffle, X_val, y_val, verbose,
                           w, val_w)

    def partial_fit(self, X, y, classes=None, epochs=1, shuffle=True, X_val=None, y_val=None, verbose=False,
                    sample_weight=None):
        """Continue training from the current state (the first call builds the model).

        classes: every label that will ever appear, needed on the first call if one batch lacks some classes.
        sample_weight: see :meth:`fit`. ``class_weight="balanced"`` is not allowed here (a batch does not show the
            true class frequencies); use a dict.
        """
        y = np.asarray(y)
        if isinstance(self.class_weight, str):
            raise ValueError('class_weight="balanced" cannot be used with partial_fit; pass a dict instead')
        all_classes = self.classes_ if self._core is not None else (y if classes is None else classes)
        w, cw = self._row_weights(y, all_classes, sample_weight)
        val_w = self._val_weights(cw, all_classes, y_val)
        return self._train(X, y, classes, epochs, shuffle, X_val, y_val, verbose, w, val_w)

    @staticmethod
    def _val_weights(cw, classes, y_val):
        """Class weights for user-supplied validation rows (None without class weights or validation data)."""
        if cw is None or y_val is None:
            return None
        return cw[np.searchsorted(np.unique(classes), np.asarray(y_val))]

    def _epoch_rows(self, w, n):
        """Row indices for one epoch under weights ``w`` (None = all rows once); see :meth:`fit`."""
        if w is None:
            return None
        scale = w * (n / w.sum())
        whole = np.floor(scale)
        rng = np.random.default_rng([int(self.random_state), len(self.history_)])
        copies = (whole + (rng.random(n) < scale - whole)).astype(np.int64)
        return np.repeat(np.arange(n), copies)

    def _train(self, X, y, classes, epochs, shuffle, X_val, y_val, verbose, row_w=None, val_w=None):
        names = np.asarray(X.columns, dtype=object) if hasattr(X, "columns") else None
        X = self._bits(X)
        y = np.asarray(y)
        if len(X) != len(y):
            raise ValueError("X and y have different lengths")
        if self._core is None:
            self._init(X, y, classes, names)
        elif X.shape[1] != self.n_features_:
            raise ValueError("X has %d features, expected %d" % (X.shape[1], self.n_features_))
        y_idx = self._encode(y)
        if X_val is not None:
            X_val = self._bits(X_val)
            y_val = np.asarray(y_val)

        for _ in range(epochs):
            t0 = time.perf_counter()
            rows = self._epoch_rows(row_w, len(X))
            if rows is None:
                self._core.fit_epoch(X, y_idx, shuffle)
            else:
                self._core.fit_epoch(np.ascontiguousarray(X[rows]), np.ascontiguousarray(y_idx[rows]), shuffle)
            seconds = time.perf_counter() - t0
            self._packed = None
            record = {"epoch": len(self.history_) + 1, "seconds": seconds}
            if X_val is not None:
                hit = self.classes_[self.to_packed().predict(X_val)] == y_val
                use_w = val_w is not None and val_w.sum() > 0
                record["val_accuracy"] = float(np.average(hit, weights=val_w) if use_w else hit.mean())
                if self.best_val_accuracy_ is None or record["val_accuracy"] > self.best_val_accuracy_:
                    self.best_val_accuracy_ = record["val_accuracy"]
                    self.best_epoch_ = record["epoch"]
                    self.best_model_ = self._packed  # immutable snapshot of the best epoch so far
            self._after_epoch(record)
            self.history_.append(record)
            if verbose:
                print(record)
        return self

    def _model(self):
        """The model used for prediction: the best validation epoch when there was validation data."""
        self._check_fitted()
        return self.best_model_ if self.best_model_ is not None else self.to_packed()

    # -- model export / inference ----------------------------------------------------------------
    @property
    def clauses_(self):
        """Included literals, shape (n_classes * clauses_per_class, 2 * n_features); columns [x, not x]."""
        self._check_fitted()
        out = np.empty((self._core.n_clauses, 2 * self.n_features_), dtype=np.uint8)
        self._core.export_include(out)
        return out

    @property
    def weights_(self):
        """Clause weights, shape (n_classes * clauses_per_class,); all 1 unless ``weighted=True``."""
        self._check_fitted()
        out = np.empty(self._core.n_clauses, dtype=np.int32)
        self._core.export_weights(out)
        return out

    def to_packed(self):
        """Compile the trained clauses into a :class:`PackedModel` (empty clauses never vote).

        The model predicts class indices; ``save`` attaches the labels and the threshold.
        """
        self._check_fitted()
        if self._packed is None:
            self._packed = PackedModel(self.clauses_, self._vote_weights(), self.n_features_)
        return self._packed

    def _labelled(self, best):
        """The current (or best-validation) model as a PackedModel carrying labels, T and feature names."""
        self._check_fitted()
        model = self.best_model_ if best and self.best_model_ is not None else self.to_packed()
        out = model.with_metadata(classes=self.classes_, T=self.T_,
                                  feature_names=getattr(self, "feature_names_in_", None))
        out.calibrator = getattr(self, "_calibration", None)
        return out

    # Prediction uses the best validation epoch when fit had validation data (X_val, or the automatic hold-out of
    # T="auto"), otherwise the latest epoch. to_packed() always gives the latest epoch.
    def decision_function(self, X):
        return self._model().decision_function(self._bits(X))

    def predict(self, X):
        return self.classes_[self._model().predict(self._bits(X))]

    def predict_proba(self, X):
        """Class scores turned into probabilities (see :meth:`PackedModel.predict_proba`); not calibrated."""
        return self._labelled(best=True).predict_proba(self._bits(X))

    def score(self, X, y):
        return float((self.predict(X) == np.asarray(y)).mean())

    def rules(self, feature_names=None, top=None, best=False):
        """Learned clauses as readable rules; see :meth:`PackedModel.rules`."""
        return self._labelled(best).rules(feature_names, top)

    def rule_report(self, X, y=None, feature_names=None, top=None, min_support=0.0, best=False):
        """Rules with how often they fire (and how often they are right) on ``X``; see
        :meth:`PackedModel.rule_report`."""
        return self._labelled(best).rule_report(self._bits(X), y, feature_names, top, min_support)

    def feature_importance(self, X=None, best=False):
        """Importance of every feature, summing to 1; see :meth:`PackedModel.feature_importance`."""
        return self._labelled(best).feature_importance(None if X is None else self._bits(X))

    def simplify(self, X, tolerance=0.0, best=False):
        """A shorter :class:`PackedModel` (same answers on ``X`` when ``tolerance`` is 0); see
        :meth:`PackedModel.simplify`."""
        return self._labelled(best).simplify(self._bits(X), tolerance)

    def prune(self, X, min_fires=1, max_literals=None, min_weight=0, best=False):
        """A :class:`PackedModel` without rarely-used or overlong clauses; see :meth:`PackedModel.prune`."""
        return self._labelled(best).prune(self._bits(X), min_fires, max_literals, min_weight)

    def calibrate(self, X, y, bias=True):
        """Learn calibrated probabilities on held-out rows; ``predict_proba`` then returns them.
        Returns ``self``. Retraining (``fit``) removes the calibration."""
        self._calibration = self._labelled(best=True).calibrate(self._bits(X), y, bias).calibrator
        return self

    def explain(self, x, feature_names=None, top=10, best=False):
        """Why one sample got its prediction; see :meth:`PackedModel.explain`."""
        return self._labelled(best).explain(self._bits(np.atleast_2d(x))[0], feature_names, top)

    def save(self, path, best=True):
        """Write an inference model to ``path`` (the best-validation epoch when there is one); load with
        :func:`bittm.load`. Training state is not saved, so a loaded model cannot be trained further."""
        self._labelled(best).save(path)

    def _check_fitted(self):
        if self._core is None:
            raise RuntimeError("call fit first")


class CoalescedTsetlinMachine(TsetlinMachine):
    """Coalesced multiclass Tsetlin Machine: one pool of ``n_clauses`` clauses shared by every class.

    Each clause has a signed integer weight per class; positive weights vote for the class, negative against.
    The sign also decides which feedback the clause receives for that class. Sharing clauses lets one pattern
    serve several classes, so it usually needs far fewer clauses than the vanilla machine for the same accuracy.
    Typical T is larger than for the vanilla machine (it scales with the weights).

    n_jobs: split the clauses over this many threads. Training is deterministic for a given random_state and
        n_jobs, but results differ between different n_jobs because each thread has its own random stream.
    negative_sampling: which wrong class gets Type II-side feedback for each example. ``"focused"`` picks it with
        probability proportional to its (clipped) vote, so the classes most confused with the true one are corrected
        most; ``"uniform"`` picks any other class with equal probability. Identical for two classes.
    T, s: a number, or "auto" to choose it inside ``fit`` from held-out data (see :meth:`fit`). The values used are
        ``T_`` and ``s_``.
    random_init: start every automaton at random just below or just above the include line, so about half of all
        literals start included (as Green Tsetlin does). The default (False) starts every clause empty. A random start
        learns more slowly at first but can keep improving for longer (Fashion-MNIST: see docs/training-and-findings.md).
    """

    # Defaults chosen by bench/defaults.py (validation splits of the six scorecard datasets) and checked on four
    # other datasets by bench/defaults_check.py; see docs/training-and-findings.md section 6h.
    def __init__(self, n_clauses=2000, T="auto", s=10.0, boost_true_positive=True, n_states=127, literal_budget=None,
                 n_jobs=1, random_state=0, epochs=40, negative_sampling="focused", random_init=False,
                 validation_fraction=0.1, refit=True, cv="auto", class_weight=None):
        self.n_clauses = n_clauses
        self.cv = cv
        self.validation_fraction = validation_fraction
        self.refit = refit
        self.n_jobs = n_jobs
        self.negative_sampling = negative_sampling
        self.random_init = random_init
        super().__init__(clauses_per_class=2, T=T, s=s, boost_true_positive=boost_true_positive,
                         n_states=n_states, weighted=True, literal_budget=literal_budget, random_state=random_state,
                         epochs=epochs, class_weight=class_weight)

    def _validate(self):
        super()._validate()
        if self.n_clauses < 1:
            raise ValueError("n_clauses must be >= 1")
        if self.n_jobs < 1:
            raise ValueError("n_jobs must be >= 1")
        if self.negative_sampling not in ("focused", "uniform"):
            raise ValueError("negative_sampling must be 'focused' or 'uniform'")
        if not 0.0 <= self.validation_fraction < 1.0:
            raise ValueError("validation_fraction must be in [0, 1)")
        if self.cv not in (None, "auto") and (isinstance(self.cv, bool) or not isinstance(self.cv, (int, np.integer))
                                              or self.cv < 2):
            raise ValueError('cv must be "auto", None or an integer >= 2')

    # T="auto": a small search inside fit. Each candidate T = ratio x clauses per class is trained for the full
    # number of epochs and scored on held-out data (X_val, or validation_fraction of the training rows kept back);
    # ratios 1, 4, 16, 64 first, then half and double the best. The best run is kept as the fitted model.
    # A rule that re-set T every epoch from the error was tried first and failed on new datasets (training-and-
    # findings 6h): a too-large T keeps the error high, which keeps T large.
    AUTO_T_RATIOS = (1.0, 4.0, 16.0, 64.0)
    AUTO_T_FALLBACK_RATIO = 4.0  # partial_fit, or too little data to hold any back
    # s="auto": after T is chosen (at s = 10), try s = 5 and 20 with that T; if one of them wins, go one step further
    # the same way (2.5 or 40). Halving and doubling s is enough: accuracy changes slowly with s.
    AUTO_S_START = 10.0
    AUTO_S_STEP = 2.0

    def _check_T(self):
        if self.T != "auto":
            super()._check_T()

    def _check_s(self):
        if self.s != "auto":
            super()._check_s()

    @property
    def s_(self):
        """The specificity in use (chosen by the search when s="auto")."""
        return float(getattr(self, "_s_fit", self.AUTO_S_START if self.s == "auto" else self.s))

    def _ratio_T(self, ratio, n_classes):
        return max(1, int(round(ratio * self.n_clauses / n_classes)))

    @property
    def T_(self):
        """The threshold in use (chosen by the search when T="auto")."""
        return self._core.threshold if self._core is not None else self.T

    def fit(self, X, y, epochs=None, shuffle=True, X_val=None, y_val=None, verbose=False, sample_weight=None):
        """Train from scratch for ``epochs`` passes (default: the ``epochs`` parameter).

        sample_weight: one non-negative number per row, combined with ``class_weight``; see
        :meth:`TsetlinMachine.fit`. The T and s search and cross-validation score weighted accuracy.

        X_val / y_val: score after every epoch, keep the best epoch in ``best_model_`` and predict with it.
        With T="auto" (default) several values of T are trained and the best on the validation data is kept; with
        s="auto", a few values of s are then tried with that T. Without X_val, ``validation_fraction`` of the training
        rows are kept back for this, and with ``refit=True`` the chosen T and s are trained once more on all rows for
        the best epoch count found. The scores are in ``T_search_`` and ``s_search_``.
        With ``cv=k`` (and no X_val) every candidate is trained k times instead, each time scored on a different
        k-th of the rows, and the mean score decides; the winner is then always refit on all rows. Costs about k
        times more, but every row helps to choose, which matters on small datasets. ``cv="auto"`` (default) uses
        3 folds below 5,000 training rows and the hold-out above; ``cv=None`` always uses the hold-out.
        """
        if self.T != "auto" and self.s != "auto":
            self.T_search_ = self.s_search_ = None
            return super().fit(X, y, epochs, shuffle, X_val, y_val, verbose, sample_weight)
        self._validate()
        names = np.asarray(X.columns, dtype=object) if hasattr(X, "columns") else None
        X, y = self._bits(X), np.asarray(y)
        classes = np.unique(y)
        w, cw = self._row_weights(y, classes, sample_weight)
        w_all, val_w = w, self._val_weights(cw, classes, y_val)
        epochs = self.epochs if epochs is None else epochs
        X_all, y_all, held_back = X, y, False
        folds = None
        k = self._n_folds(len(X))
        if X_val is None and k and len(X) // k >= 50:
            folds = self._folds(y, k)
        elif X_val is None:
            n_hold = int(round(self.validation_fraction * len(X)))
            if n_hold >= 50:
                order = np.random.default_rng(int(self.random_state)).permutation(len(X))
                X_val, y_val = X[order[:n_hold]], y[order[:n_hold]]
                keep = np.sort(order[n_hold:])
                if w is not None:
                    val_w, w = w[order[:n_hold]], w[keep]
                X, y = X[keep], y[keep]
                held_back = True

        params = self.get_params()
        runs = {}  # (T, s) -> (score, best epoch, trained machine or None for cross-validation)

        def trial(T, s):
            if (T, s) not in runs:
                if folds is None:
                    sub = type(self)(**dict(params, T=T, s=s))
                    sub._train_from_scratch(X, y, classes, epochs, shuffle, X_val, y_val, verbose, w, val_w)
                    runs[(T, s)] = (sub.best_val_accuracy_, sub.best_epoch_, sub)
                else:
                    # one run per fold, scored on that fold; the mean curve over folds picks the epoch count
                    curves = []
                    for f in range(k):
                        sub = type(self)(**dict(params, T=T, s=s))
                        sub._train_from_scratch(X[folds != f], y[folds != f], classes, epochs, shuffle,
                                                X[folds == f], y[folds == f], verbose,
                                                None if w is None else w[folds != f],
                                                None if w is None else w[folds == f])
                        curves.append([r["val_accuracy"] for r in sub.history_])
                    mean = np.mean(curves, axis=0)
                    runs[(T, s)] = (float(mean.max()), int(mean.argmax()) + 1, None)
            return runs[(T, s)][0]

        s0 = self.AUTO_S_START if self.s == "auto" else float(self.s)
        fixed_T = None if self.T == "auto" else int(self.T)
        self.T_search_ = self.s_search_ = None
        if X_val is None and folds is None:  # too little data to hold any back: one run with the middle of the grid
            T0 = fixed_T or self._ratio_T(self.AUTO_T_FALLBACK_RATIO, len(classes))
            sub = type(self)(**dict(params, T=T0, s=s0))
            sub._train_from_scratch(X, y, classes, epochs, shuffle, None, None, verbose, w)
            best = sub
        else:
            if fixed_T is None:
                score = {r: trial(self._ratio_T(r, len(classes)), s0) for r in self.AUTO_T_RATIOS}
                r0 = max(score, key=score.get)
                for r in (r0 / 2, r0 * 2):
                    trial(self._ratio_T(r, len(classes)), s0)
                self.T_search_ = {T: v[0] for (T, _), v in sorted(runs.items())}
                # on a tie the run tried first wins (grid order: 1, 4, 16, 64, then half and double of the best)
                T0 = max(runs, key=lambda k: runs[k][0])[0]
            else:
                T0 = fixed_T
                trial(T0, s0)
            if self.s == "auto":
                step = self.AUTO_S_STEP
                lo, hi = trial(T0, s0 / step), trial(T0, s0 * step)
                mid = runs[(T0, s0)][0]
                if lo > mid and lo >= hi and s0 / step / step >= 1.0:
                    trial(T0, s0 / step / step)
                elif hi > mid and hi > lo:
                    trial(T0, s0 * step * step)
                self.s_search_ = {s: v[0] for (T, s), v in sorted(runs.items()) if T == T0}
            # the best run at the chosen T; on a tie, the s closest to the start value
            T_best, s_best = max((k for k in runs if k[0] == T0),
                                 key=lambda k: (runs[k][0], -abs(np.log(k[1] / s0))))
            score, epoch, best = runs[(T_best, s_best)]
            if folds is not None or (held_back and self.refit):
                # train the chosen T and s once more on all rows, for the best epoch count found (no validation
                # data is left, so prediction uses that last epoch). Cross-validation always ends this way.
                final = type(self)(**dict(params, T=T_best, s=s_best))
                final._train_from_scratch(X_all, y_all, classes, epoch, shuffle, None, None, verbose, w_all)
                final.best_val_accuracy_, final.best_epoch_ = score, epoch
                best = final
        for k in ("classes_", "n_features_", "n_features_in_", "history_", "best_val_accuracy_", "best_epoch_",
                  "best_model_", "_core", "_packed", "_s_fit", "_calibration"):
            setattr(self, k, getattr(best, k))
        if names is not None:
            self.feature_names_in_ = names
        elif hasattr(self, "feature_names_in_"):
            del self.feature_names_in_
        return self

    # cv="auto": below this many training rows the 10% hold-out has fewer than 500 rows, where one lucky setting can
    # win by chance; there 3-fold cross-validation chooses better (training-and-findings 6h, step 6)
    CV_AUTO_MAX_ROWS = 5000
    CV_AUTO_FOLDS = 3

    def _n_folds(self, n_rows):
        if self.cv == "auto":
            return self.CV_AUTO_FOLDS if n_rows < self.CV_AUTO_MAX_ROWS else None
        return self.cv

    def _folds(self, y, k):
        """Fold number (0..k-1) for every row: shuffled, then dealt out class by class so each fold gets a fair
        share of every class."""
        order = np.random.default_rng(int(self.random_state)).permutation(len(y))
        order = order[np.argsort(y[order], kind="stable")]
        folds = np.empty(len(y), dtype=np.int64)
        folds[order] = np.arange(len(y)) % k
        return folds

    def _train_from_scratch(self, X, y, classes, epochs, shuffle, X_val, y_val, verbose, row_w=None, val_w=None):
        self._reset()
        return self._train(X, y, classes, epochs, shuffle, X_val, y_val, verbose, row_w, val_w)

    def _after_epoch(self, record):
        _, _, seen, mistakes = self._core.stats()
        prev_seen, prev_mistakes = getattr(self, "_seen", (0.0, 0.0))
        self._seen = (seen, mistakes)
        record["train_error"] = (mistakes - prev_mistakes) / max(seen - prev_seen, 1.0)  # each example before its update
        record["T"] = self._core.threshold

    def _make_core(self):
        self._seen = (0.0, 0.0)
        T = self._ratio_T(self.AUTO_T_FALLBACK_RATIO, len(self.classes_)) if self.T == "auto" else self.T
        self._s_fit = s = self.AUTO_S_START if self.s == "auto" else float(self.s)
        return _core.CoalescedTrainer(self.n_features_, len(self.classes_), self.n_clauses, T, s,
                                      self.boost_true_positive, self.n_states, int(self.literal_budget or 0),
                                      self.n_jobs, int(self.random_state), self.negative_sampling == "focused",
                                      bool(self.random_init))

    @property
    def weights_(self):
        """Clause weights, shape (n_clauses, n_classes)."""
        self._check_fitted()
        out = np.empty((self._core.n_clauses, len(self.classes_)), dtype=np.int32)
        self._core.export_weights(out)
        return out

    def _vote_weights(self):
        return self.weights_
