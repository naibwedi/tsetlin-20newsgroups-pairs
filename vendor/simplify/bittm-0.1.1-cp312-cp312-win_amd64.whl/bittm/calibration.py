"""Calibrated probabilities for Tsetlin Machine votes.

A Tsetlin Machine's class votes are integers; ``PackedModel.predict_proba`` ranks them but the numbers are not true
probabilities. :class:`VoteCalibrator` learns a monotone map from votes to probabilities on held-out data:
``softmax(a * vote / scale + b_k)``. For two classes this is Platt scaling. The fit is convex, so it needs no
tuning and always reaches the same answer.
"""
import numpy as np


def _softmax(z):
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


class VoteCalibrator:
    """Maps vote scores (n_rows, n_classes) to probabilities. Fit on rows the model did not train on."""

    def __init__(self, bias=True, max_iter=500):
        self.bias = bias
        self.max_iter = max_iter
        self.a_ = None
        self.b_ = None
        self.scale_ = None

    def fit(self, scores, y):
        """scores: (n, K) votes; y: class indices 0..K-1."""
        S = np.asarray(scores, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        n, K = S.shape
        if len(y) != n:
            raise ValueError("scores and y have different lengths")
        if y.min() < 0 or y.max() >= K:
            raise ValueError("y must hold class indices in [0, %d)" % K)
        self.scale_ = float(max(np.abs(S).max(), 1.0))
        Z = S / self.scale_
        onehot = np.zeros((n, K))
        onehot[np.arange(n), y] = 1.0

        def loss(a, b):
            p = _softmax(a * Z + b)
            return -np.log(np.maximum(p[np.arange(n), y], 1e-12)).mean()

        a, b = 1.0, np.zeros(K)
        for _ in range(self.max_iter):
            p = _softmax(a * Z + b)
            g = p - onehot
            ga = float((g * Z).sum() / n)
            gb = g.mean(axis=0) if self.bias else np.zeros(K)
            if abs(ga) + np.abs(gb).max() < 1e-7:
                break
            step, base = 1.0, loss(a, b)
            while step > 1e-10:  # backtracking line search (the loss is convex, so this always makes progress)
                a2, b2 = a - step * ga * 5.0, b - step * gb * 5.0
                if loss(a2, b2) < base - 1e-12:
                    a, b = a2, b2
                    break
                step *= 0.5
            else:
                break
        self.a_, self.b_ = float(a), b - b.mean()
        return self

    def predict_proba(self, scores):
        if self.a_ is None:
            raise RuntimeError("call fit first")
        S = np.asarray(scores, dtype=np.float64) / self.scale_
        return _softmax(self.a_ * S + self.b_)

    def to_dict(self):
        return {"a": self.a_, "b": [float(v) for v in self.b_], "scale": self.scale_}

    @classmethod
    def from_dict(cls, d):
        out = cls()
        out.a_, out.b_, out.scale_ = float(d["a"]), np.asarray(d["b"], dtype=np.float64), float(d["scale"])
        return out
