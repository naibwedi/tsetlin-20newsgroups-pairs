# The single place the version is set. pyproject.toml reads it from here; bump it when releasing (see CHANGELOG.md).
__version__ = "0.1.1"
