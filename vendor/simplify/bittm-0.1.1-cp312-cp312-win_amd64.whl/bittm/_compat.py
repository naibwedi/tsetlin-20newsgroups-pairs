"""scikit-learn base classes when scikit-learn is installed, minimal stand-ins otherwise.

With scikit-learn the estimators work in Pipeline, GridSearchCV, clone and cross_val_score; without it they still
have get_params / set_params following the same convention (parameters are the __init__ arguments).
"""
import inspect

try:
    from sklearn.base import BaseEstimator, ClassifierMixin, TransformerMixin
except ImportError:  # pragma: no cover - exercised only without scikit-learn
    class BaseEstimator:
        @classmethod
        def _get_param_names(cls):
            return sorted(p for p in inspect.signature(cls.__init__).parameters if p != "self")

        def get_params(self, deep=True):
            return {p: getattr(self, p) for p in self._get_param_names()}

        def set_params(self, **params):
            for k, v in params.items():
                if k not in self._get_param_names():
                    raise ValueError("invalid parameter %r" % k)
                setattr(self, k, v)
            return self

    class ClassifierMixin:
        _estimator_type = "classifier"

    class TransformerMixin:
        def fit_transform(self, X, y=None):
            return self.fit(X, y).transform(X)
