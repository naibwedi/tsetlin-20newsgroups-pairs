"""Small evaluation helpers: ROC AUC, a best threshold, and repeated runs over several seeds."""
import numpy as np


def _rank(x):
    """Average ranks (1-based), ties share the mean rank."""
    order = np.argsort(x, kind="stable")
    ranks = np.empty(len(x), dtype=np.float64)
    sx = x[order]
    start = 0
    while start < len(x):
        end = start
        while end + 1 < len(x) and sx[end + 1] == sx[start]:
            end += 1
        ranks[order[start:end + 1]] = (start + end) / 2.0 + 1.0
        start = end + 1
    return ranks


def roc_auc(y_true, score):
    """Area under the ROC curve for two classes (the higher label is positive). 0.5 = chance."""
    y = np.asarray(y_true)
    score = np.asarray(score, dtype=np.float64)
    labels = np.unique(y)
    if len(labels) != 2:
        raise ValueError("roc_auc needs exactly two classes in y_true")
    pos = y == labels[1]
    n_pos, n_neg = int(pos.sum()), int((~pos).sum())
    ranks = _rank(score)
    return float((ranks[pos].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def best_threshold(y_true, score, metric="accuracy"):
    """The cut-off on ``score`` (predict positive when score > cut-off) that maximises ``metric`` ('accuracy' or
    'f1') for two classes. Choose it on validation data. Returns ``(threshold, value)``."""
    if metric not in ("accuracy", "f1"):
        raise ValueError("metric must be 'accuracy' or 'f1'")
    y = np.asarray(y_true)
    labels = np.unique(y)
    if len(labels) != 2:
        raise ValueError("best_threshold needs exactly two classes in y_true")
    pos = (y == labels[1])
    score = np.asarray(score, dtype=np.float64)
    order = np.argsort(-score, kind="stable")
    s, p = score[order], pos[order]
    tp = np.cumsum(p)
    fp = np.cumsum(~p)
    last = np.r_[s[1:] != s[:-1], True]  # only cut between different score values
    tp, fp, s = tp[last], fp[last], s[last]
    n_pos, n = int(pos.sum()), len(y)
    fn = n_pos - tp
    tn = (n - n_pos) - fp
    value = (tp + tn) / n if metric == "accuracy" else 2 * tp / np.maximum(2 * tp + fp + fn, 1)
    # the "everything positive" cut and the "everything negative" cut
    cuts = np.r_[s[0] + 1.0, (s[:-1] + s[1:]) / 2.0, s[-1] - 1.0]
    all_neg = (n - n_pos) / n if metric == "accuracy" else 0.0
    values = np.r_[all_neg, value]
    k = int(np.argmax(values))
    return float(cuts[k] if k < len(cuts) else cuts[-1]), float(values[k])


def evaluate(estimator, X, y, X_test, y_test, seeds=(0, 1, 2), **fit_kwargs):
    """Train ``estimator`` once per seed (``random_state`` is set to each seed) and score it on ``X_test``.

    Returns a dict with ``accuracy``, and for two classes ``f1`` and ``auc``, each as ``{"values", "mean", "std"}``,
    plus ``seeds``. Extra keyword arguments go to ``fit`` (e.g. ``sample_weight``).
    """
    y_test = np.asarray(y_test)
    rows = {"accuracy": [], "f1": [], "auc": []}
    for seed in seeds:
        model = type(estimator)(**dict(estimator.get_params(), random_state=seed))
        model.fit(X, y, **fit_kwargs)
        pred = model.predict(X_test)
        rows["accuracy"].append(float((pred == y_test).mean()))
        classes = np.unique(y_test)
        if len(classes) == 2:
            pos = classes[1]
            tp = float(((pred == pos) & (y_test == pos)).sum())
            fp = float(((pred == pos) & (y_test != pos)).sum())
            fn = float(((pred != pos) & (y_test == pos)).sum())
            rows["f1"].append(2 * tp / max(2 * tp + fp + fn, 1.0))
            votes = np.asarray(model.decision_function(X_test), dtype=np.float64)
            rows["auc"].append(roc_auc(y_test, votes[:, 1] - votes[:, 0]))
    out = {"seeds": list(seeds)}
    for k, v in rows.items():
        if v:
            out[k] = {"values": v, "mean": float(np.mean(v)), "std": float(np.std(v))}
    return out
