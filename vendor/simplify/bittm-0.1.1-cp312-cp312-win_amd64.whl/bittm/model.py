import copy
import hashlib
import json
import os

import numpy as np

from . import _core
from ._version import __version__
from .calibration import VoteCalibrator

_SCORES = {"auto": "scores", "single": "scores_single", "batch": "scores_batch", "index": "scores_index"}
_PREDICT = {"auto": "predict", "single": "predict_single", "batch": "predict_batch", "index": "predict_index"}

FORMAT = "bittm-model"
FORMAT_VERSION = 1


def merge_duplicate_clauses(include, weights):
    """Identical clauses vote together, so merge them and add their weights. Keeps first-occurrence order.

    Rows are bit-packed into 64-bit words and grouped by a hash; neighbours in hash order are also compared word by
    word, so two different clauses are never merged even if their hashes collide. (np.unique(axis=0) did the same job
    with a byte-wise sort and took about a third of fit time on MNIST.)
    """
    include = np.ascontiguousarray(include, dtype=np.uint8)
    weights = np.asarray(weights, dtype=np.int64)
    keep = include.any(axis=1)  # empty clauses never vote at test time
    include, weights = include[keep], weights[keep]
    n = len(include)
    if n == 0:
        return include, weights.astype(np.int32)
    packed = np.packbits(include, axis=1)
    pad = (-packed.shape[1]) % 8
    if pad:
        packed = np.concatenate([packed, np.zeros((n, pad), np.uint8)], axis=1)
    words = np.ascontiguousarray(packed).view(np.uint64)  # (n, words)
    h = np.zeros(n, dtype=np.uint64)
    with np.errstate(over="ignore"):
        for j in range(words.shape[1]):
            h = (h ^ words[:, j]) * np.uint64(0x9E3779B97F4A7C15)
            h ^= h >> np.uint64(29)
    order = np.argsort(h, kind="stable")
    hs, ws = h[order], words[order]
    new = np.ones(n, dtype=bool)  # True where a new group starts in hash order
    new[1:] = (hs[1:] != hs[:-1]) | (ws[1:] != ws[:-1]).any(axis=1)
    group = np.cumsum(new) - 1                     # group of each row, in hash order
    first = order[new]                             # first row (lowest index) of each group
    rank = np.argsort(first)                       # groups in first-occurrence order
    pos = np.empty(len(first), dtype=np.int64)
    pos[rank] = np.arange(len(first))
    inverse = np.empty(n, dtype=np.int64)
    inverse[order] = pos[group]
    merged = np.zeros((len(first), weights.shape[1]), dtype=np.int64)
    np.add.at(merged, inverse, weights)
    uniq = include[first[rank]]
    nonzero = merged.any(axis=1)  # clauses whose weights cancel (e.g. +1 and -1) never change a prediction
    return uniq[nonzero], merged[nonzero].astype(np.int32)


class Rule:
    """One clause: an AND of literals, and what it adds to each class's score when it fires."""

    def __init__(self, literals, weights, contribution=None, negated=None):
        self.literals = literals          # list of literal names
        self.weights = weights            # {class label: weight}, non-zero weights only
        self.contribution = contribution  # set by explain(): the weight for the explained class
        self.negated = negated if negated is not None else [False] * len(literals)  # True where the literal is "NOT x"
        self.support = None               # set by rule_report(): share of rows on which the rule fires
        self.precision = None             # set by rule_report(): share of those rows where its strongest class is right

    @property
    def positive_literals(self):
        """Names of the literals that say "x is present" (not the negated ones)."""
        return [l for l, n in zip(self.literals, self.negated) if not n]

    def text(self, show_negated=True):
        """The rule as a string. With ``show_negated=False`` the "NOT ..." literals are replaced by a count, so a
        long rule built mostly from absences reads as its few positive conditions plus "(+N absent)"."""
        if show_negated:
            lits = self.literals
            extra = ""
        else:
            lits = self.positive_literals
            n_neg = len(self.literals) - len(lits)
            extra = " (+%d absent)" % n_neg if n_neg else ""
        cond = " AND ".join(lits) if lits else "(always)"
        votes = ", ".join("%+d %s" % (w, k) for k, w in sorted(self.weights.items(), key=lambda kv: -abs(kv[1])))
        stats = ""
        if self.support is not None:
            stats = "  [fires %.1f%%" % (100 * self.support)
            stats += ", right %.0f%%]" % (100 * self.precision) if self.precision is not None else "]"
        return "IF %s%s THEN %s%s" % (cond, extra, votes, stats)

    def __repr__(self):
        return self.text()


class PackedModel:
    """Inference-only Tsetlin Machine over bit-packed clauses.

    include: (n_clauses, 2 * n_features) 0/1, columns [x_0..x_n-1, not x_0..not x_n-1]
    weights: (n_clauses, n_classes) integer clause weights / polarities

    Optional metadata (attached by ``TsetlinMachine.save`` and restored by :func:`load`):
    ``classes_`` (labels; when set, ``predict`` returns labels instead of class indices), ``T`` (vote threshold,
    used by ``predict_proba``) and ``feature_names`` (used by ``rules`` and ``explain``).
    """

    def __init__(self, include, weights, n_features=None):
        include = np.asarray(include)
        if n_features is None:
            n_features = include.shape[1] // 2
        include, weights = merge_duplicate_clauses(include, weights)
        self.n_features = int(n_features)
        self.include_, self.weights_ = include, weights
        self.classes_ = None
        self.T = None
        self.feature_names = None
        self.calibrator = None
        self._core = _core.Model(include, np.ascontiguousarray(weights), self.n_features)

    @classmethod
    def from_green_tsetlin(cls, state):
        """Build from a green_tsetlin DenseState (literal is included when state >= 0)."""
        return cls(np.asarray(state.c) >= 0, state.w)

    def with_metadata(self, classes=None, T=None, feature_names=None):
        """A copy sharing the compiled clauses, with labels, threshold and feature names attached.
        A calibration (see :meth:`calibrate`) is kept."""
        out = copy.copy(self)
        out.classes_ = None if classes is None else np.asarray(classes)
        out.T = T
        out.feature_names = None if feature_names is None else [str(f) for f in feature_names]
        if out.classes_ is not None and len(out.classes_) != self.n_classes:
            raise ValueError("expected %d class labels, got %d" % (self.n_classes, len(out.classes_)))
        return out

    @property
    def n_clauses(self):
        return self._core.n_clauses

    @property
    def n_classes(self):
        return self._core.n_classes

    @property
    def mean_words_per_clause(self):
        return self._core.mean_words_per_clause

    @property
    def memory_bytes(self):
        return self._core.memory_bytes

    def _x(self, X):
        return np.ascontiguousarray(X, dtype=np.uint8)

    def optimize_order(self, X_sample):
        """Test the most-likely-to-fail mask word first (post-training, pre-inference)."""
        self._core.optimize_order(self._x(X_sample))
        return self

    def decision_function(self, X, mode="auto"):
        """mode: 'auto' (batch path for >= 32 samples), 'single' (early-exit path) or 'batch' (bit-sliced)."""
        X = self._x(X)
        out = np.empty((X.shape[0], self.n_classes), dtype=np.int32)
        getattr(self._core, _SCORES[mode])(X, out)
        return out

    def predict(self, X, mode="auto"):
        """Class indices, or labels when the model carries ``classes_``."""
        X = self._x(X)
        out = np.empty(X.shape[0], dtype=np.int32)
        getattr(self._core, _PREDICT[mode])(X, out)
        return out if self.classes_ is None else self.classes_[out]

    def predict_proba(self, X):
        """Each class's clipped vote, shifted to [0, 2T] and normalised to sum to 1.

        The highest probability always matches ``predict``. The values are a ranking of the vote margin, not
        calibrated probabilities; wrap the machine in scikit-learn's ``CalibratedClassifierCV`` if you need those.
        Without ``T`` (models not saved by a TsetlinMachine) the largest absolute score per row is used.
        After :meth:`calibrate` the values are calibrated probabilities instead (their argmax can then differ from
        ``predict`` on rows near a tie, because calibration may shift one class's score).
        """
        if self.calibrator is not None:
            return self.calibrator.predict_proba(self.decision_function(X))
        v = self.decision_function(X).astype(np.float64)
        T = np.full((len(v), 1), float(self.T)) if self.T else np.maximum(np.abs(v).max(axis=1, keepdims=True), 1.0)
        v = np.clip(v, -T, T) + T
        total = v.sum(axis=1, keepdims=True)
        return np.where(total > 0, v / np.where(total > 0, total, 1), 1.0 / self.n_classes)

    def calibrate(self, X, y, bias=True):
        """Learn calibrated probabilities from held-out rows ``X`` with labels ``y`` (labels, or class indices when the
        model carries no ``classes_``). Afterwards ``predict_proba`` returns them, and ``save`` stores them.
        Use data the model was not trained on, or the probabilities will be too confident. Returns ``self``."""
        y = np.asarray(y)
        if self.classes_ is not None:
            idx = np.searchsorted(self.classes_, y)
            if (idx >= len(self.classes_)).any() or (self.classes_[np.minimum(idx, len(self.classes_) - 1)] != y).any():
                raise ValueError("y contains a label the model does not know")
            y = idx
        self.calibrator = VoteCalibrator(bias=bias).fit(self.decision_function(X), y)
        return self

    def mean_words_tested(self, X):
        return self._core.mean_words_tested(self._x(X))

    # -- interpretability ---------------------------------------------------------------------------
    def _literal_names(self, feature_names):
        names = feature_names if feature_names is not None else self.feature_names
        n = self.n_features
        if names is None:
            names = ["x%d" % j for j in range(n)]
        names = [str(f) for f in names]
        if len(names) == 2 * n:
            return names
        if len(names) != n:
            raise ValueError("feature_names needs %d (features) or %d (literals) names, got %d"
                             % (n, 2 * n, len(names)))
        return names + ["NOT " + f for f in names]

    def _labels(self):
        return self.classes_.tolist() if self.classes_ is not None else list(range(self.n_classes))  # plain Python values

    def _rule(self, c, names, labels):
        idx = np.flatnonzero(self.include_[c])
        return Rule([names[j] for j in idx], {labels[k]: int(w) for k, w in enumerate(self.weights_[c]) if w},
                    negated=[bool(j >= self.n_features) for j in idx])

    def rules(self, feature_names=None, top=None):
        """Every clause as a :class:`Rule`, strongest first (by largest absolute weight).

        feature_names: one name per feature (negations are written ``NOT name``), or one per literal, e.g.
            ``Booleanizer.get_literal_names_out()`` which writes them as ``age <= 37``.
        """
        names, labels = self._literal_names(feature_names), self._labels()
        order = np.argsort(-np.abs(self.weights_).max(axis=1), kind="stable")
        if top is not None:
            order = order[:top]
        return [self._rule(int(c), names, labels) for c in order]

    def explain(self, x, feature_names=None, top=10):
        """Why one sample (a 1-D 0/1 vector) got its prediction.

        Returns a dict: ``prediction``, ``scores`` ({label: total vote}) and ``rules``, the fired clauses
        with the largest effect on the predicted class, each with ``contribution`` set to its weight there.
        """
        x = self._x(np.asarray(x).reshape(1, -1))[0]
        if len(x) != self.n_features:
            raise ValueError("x has %d features, expected %d" % (len(x), self.n_features))
        lit = np.concatenate([x, 1 - x]).astype(bool)
        fired = ~(self.include_.astype(bool) & ~lit).any(axis=1)
        scores = fired.astype(np.int64) @ self.weights_.astype(np.int64)
        k = int(np.argmax(scores))  # ties go to the lowest index, as in predict
        names, labels = self._literal_names(feature_names), self._labels()
        idx = np.flatnonzero(fired & (self.weights_[:, k] != 0))
        idx = idx[np.argsort(-np.abs(self.weights_[idx, k]), kind="stable")][:top]
        rules = []
        for c in idx:
            r = self._rule(int(c), names, labels)
            r.contribution = int(self.weights_[c, k])
            rules.append(r)
        return {"prediction": labels[k], "scores": {labels[i]: int(s) for i, s in enumerate(scores)}, "rules": rules}

    # -- rule statistics, pruning and simplifying ---------------------------------------------------
    def _fire_matrix(self, X):
        """(n_rows, n_clauses) bool: which clauses fire on which rows."""
        X = self._x(X)
        if X.ndim != 2 or X.shape[1] != self.n_features:
            raise ValueError("X must have shape (n_rows, %d)" % self.n_features)
        lit = np.concatenate([X, 1 - X], axis=1).astype(np.float32)
        inc = self.include_.astype(np.float32)
        return (lit @ inc.T) == inc.sum(axis=1)[None, :]  # a clause fires when all its literals are true

    def rule_report(self, X, y=None, feature_names=None, top=None, min_support=0.0):
        """Rules with usage statistics measured on ``X``, most-used first.

        Each :class:`Rule` gets ``support`` (share of rows on which it fires) and, when labels ``y`` are given,
        ``precision`` (share of those rows whose label is the rule's strongest class). Rules that fire on less than
        ``min_support`` of the rows are left out.
        """
        fired = self._fire_matrix(X)
        support = fired.mean(axis=0)
        names, labels = self._literal_names(feature_names), self._labels()
        order = [int(c) for c in np.argsort(-support, kind="stable") if support[c] > 0 and support[c] >= min_support]
        if top is not None:
            order = order[:top]
        if y is not None:
            y = np.asarray(y)
            if len(y) != len(fired):
                raise ValueError("X and y have different lengths")
            lab = np.asarray(labels, dtype=object)
        out = []
        for c in order:
            r = self._rule(c, names, labels)
            r.support = float(support[c])
            if y is not None:
                best = lab[int(np.argmax(self.weights_[c]))]
                r.precision = float((y[fired[:, c]] == best).mean())
            out.append(r)
        return out

    def feature_importance(self, X=None):
        """Importance of every feature (both its "x" and "NOT x" literals), normalised to sum to 1.

        Each clause shares its largest absolute weight equally between its literals, so a short rule counts more
        per literal than a rule with hundreds. With ``X``, each clause is also scaled by how often it fires there.
        """
        w = np.abs(self.weights_).max(axis=1).astype(np.float64)
        n_lit = np.maximum(self.include_.sum(axis=1), 1)
        share = w / n_lit
        if X is not None:
            share = share * self._fire_matrix(X).mean(axis=0)
        per_literal = self.include_.astype(np.float64).T @ share
        imp = per_literal[:self.n_features] + per_literal[self.n_features:]
        total = imp.sum()
        return imp / total if total > 0 else imp

    def prune(self, X, min_fires=1, max_literals=None, min_weight=0):
        """A new model without the clauses that fire fewer than ``min_fires`` times on ``X``, have more than
        ``max_literals`` literals, or whose largest absolute weight is below ``min_weight``.

        Pruning can change predictions (the removed clauses no longer vote); check accuracy on held-out data.
        """
        fired_n = self._fire_matrix(X).sum(axis=0)
        keep = fired_n >= min_fires
        if max_literals is not None:
            keep &= self.include_.sum(axis=1) <= max_literals
        keep &= np.abs(self.weights_).max(axis=1) >= min_weight
        out = PackedModel(self.include_[keep], self.weights_[keep], self.n_features)
        return out.with_metadata(self.classes_, self.T, self.feature_names)

    def simplify(self, X, tolerance=0.0):
        """A shorter model. With the default ``tolerance=0`` it gives **exactly the same answers on every row of**
        ``X``.

        For each clause, a literal is dropped when removing it does not change the set of rows on which the clause
        fires. This removes absences ("NOT word") that are true on every row anyway. Rules built from rare words
        often cannot be shortened exactly, so ``tolerance`` (a share of the rows, e.g. 0.01) lets each clause fire on
        up to that share of extra rows in exchange for dropping more literals. Then answers can change: check accuracy
        on held-out data. On rows unlike ``X`` the shortened rules may fire more often than the originals, so use the
        training data (or similar) for ``X``.
        """
        if not 0.0 <= tolerance < 1.0:
            raise ValueError("tolerance must be in [0, 1)")
        X = self._x(X)
        lit = np.concatenate([X, 1 - X], axis=1).astype(bool)
        new = np.zeros_like(self.include_)
        for c in range(len(self.include_)):
            original = np.flatnonzero(self.include_[c])
            if len(original) == 0:
                continue
            miss = ~lit[:, original]                   # (rows, literals): True where the literal is false
            keep = original[miss.any(axis=0)]          # a literal that is true on every row never matters
            if len(keep) == 0:                         # the clause fires on every row: keep one literal so it still votes
                new[c, original[:1]] = 1
                continue
            miss = ~lit[:, keep]
            viol = miss.sum(axis=1)
            alive = np.ones(len(keep), dtype=bool)
            budget, used = int(tolerance * len(X)), 0
            for j in np.argsort(miss.sum(axis=0), kind="stable"):  # try the least-violated literals first
                cost = int((miss[:, j] & (viol == 1)).sum())       # rows that this literal alone rejects
                if used + cost <= budget:
                    used += cost
                    viol = viol - miss[:, j]
                    alive[j] = False
            if alive.sum() == 0:                                   # never drop a clause's last literal
                alive[int(np.argmax(miss.sum(axis=0)))] = True
            new[c, keep[alive]] = 1
        out = PackedModel(new, self.weights_, self.n_features)
        return out.with_metadata(self.classes_, self.T, self.feature_names)

    # -- persistence --------------------------------------------------------------------------------
    def save(self, path):
        """Write the model to ``path`` (a NumPy .npz archive, no pickled objects) with a format version and a
        SHA-256 checksum of the clause data."""
        packed = np.packbits(self.include_.astype(np.uint8), axis=1)
        weights = np.ascontiguousarray(self.weights_, dtype=np.int32)
        meta = {
            "format": FORMAT, "version": FORMAT_VERSION, "n_features": self.n_features,
            "n_clauses": int(len(self.include_)), "n_classes": self.n_classes,
            "T": None if self.T is None else int(self.T),
            "classes": None if self.classes_ is None else self.classes_.tolist(),
            "classes_dtype": None if self.classes_ is None else self.classes_.dtype.str,
            "feature_names": self.feature_names, "sha256": _digest(packed, weights),
            "bittm_version": __version__,  # informational: which release wrote the file
        }
        if self.calibrator is not None:
            meta["calibration"] = self.calibrator.to_dict()
        with open(os.fspath(path), "wb") as f:  # a file object stops numpy appending ".npz" to the name
            np.savez_compressed(f, include=packed, weights=weights, meta=np.array(json.dumps(meta)))


def _digest(packed, weights):
    return hashlib.sha256(packed.tobytes() + weights.tobytes()).hexdigest()


def load(path):
    """Read a model written by ``save``; checks the format, version and checksum."""
    with np.load(os.fspath(path), allow_pickle=False) as z:
        try:
            meta = json.loads(str(z["meta"]))
            packed, weights = z["include"], z["weights"]
        except KeyError as e:
            raise ValueError("not a bittm model file: missing %s" % e) from None
    if meta.get("format") != FORMAT:
        raise ValueError("not a bittm model file")
    if meta["version"] > FORMAT_VERSION:
        raise ValueError("model file version %d is newer than this bittm (reads up to %d); upgrade bittm"
                         % (meta["version"], FORMAT_VERSION))
    if _digest(packed, weights) != meta["sha256"]:
        raise ValueError("model file is corrupted (checksum mismatch)")
    n = meta["n_features"]
    include = np.unpackbits(packed, axis=1, count=2 * n)
    model = PackedModel(include, weights, n)
    classes = None
    if meta["classes"] is not None:
        classes = np.array(meta["classes"], dtype=np.dtype(meta["classes_dtype"]))
    model = model.with_metadata(classes=classes, T=meta["T"], feature_names=meta["feature_names"])
    if meta.get("calibration"):
        model.calibrator = VoteCalibrator.from_dict(meta["calibration"])
    return model
