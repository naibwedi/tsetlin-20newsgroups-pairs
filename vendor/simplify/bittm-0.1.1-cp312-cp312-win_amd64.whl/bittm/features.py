"""Text and pair features: turn raw text into the 0/1 bits a Tsetlin Machine needs, with readable names."""
import re

import numpy as np

from ._compat import BaseEstimator, TransformerMixin

# a short list of very common English words; pass your own collection to ``stop_words`` for other languages
ENGLISH_STOP_WORDS = frozenset("""
a about after all also an and any are as at be been but by can could did do does for from had has have he her his
how i if in into is it its just may me more most my no not of on one or our out she so some than that the their them
then there these they this to up us was we were what when which who will with would you your
""".split())


class TextBooleanizer(TransformerMixin, BaseEstimator):
    """One bit per word: 1 when the word occurs in the text. The vocabulary is the ``max_features`` words found in the
    most training texts (words in fewer than ``min_df`` texts are ignored). No scikit-learn needed.

    lowercase: fold case before splitting.
    token_pattern: regular expression for a word (default: runs of 2 or more letters, so numbers are ignored).
    stop_words: None, ``"english"`` (a built-in short list) or a collection of words to ignore.
    """

    def __init__(self, max_features=1000, min_df=2, lowercase=True, token_pattern=r"[^\W\d_]{2,}", stop_words=None):
        self.max_features = max_features
        self.min_df = min_df
        self.lowercase = lowercase
        self.token_pattern = token_pattern
        self.stop_words = stop_words

    def _tokens(self, text):
        if text is None:
            return set()
        text = str(text)
        if self.lowercase:
            text = text.lower()
        words = set(re.findall(self.token_pattern, text))
        stop = ENGLISH_STOP_WORDS if self.stop_words == "english" else (self.stop_words or ())
        return words - set(stop) if stop else words

    def fit(self, X, y=None):
        if self.max_features < 1:
            raise ValueError("max_features must be >= 1")
        df = {}
        for text in X:
            for w in self._tokens(text):
                df[w] = df.get(w, 0) + 1
        words = [w for w, n in df.items() if n >= self.min_df]
        words.sort(key=lambda w: (-df[w], w))  # most common first, ties alphabetical
        self.vocabulary_ = words[:self.max_features]
        self._index = {w: j for j, w in enumerate(self.vocabulary_)}
        return self

    def transform(self, X):
        if not hasattr(self, "vocabulary_"):
            raise RuntimeError("call fit first")
        X = list(X)
        out = np.zeros((len(X), len(self.vocabulary_)), dtype=np.uint8)
        for i, text in enumerate(X):
            for w in self._tokens(text):
                j = self._index.get(w)
                if j is not None:
                    out[i, j] = 1
        return out

    def get_feature_names_out(self, input_features=None):
        return np.asarray(self.vocabulary_, dtype=object)

    def get_literal_names_out(self):
        """Names of all 2 * n_features literals, in the order the Tsetlin Machine uses: the words, then their negations."""
        return list(self.vocabulary_) + ["NOT " + w for w in self.vocabulary_]


_PAIR_NAMES = {
    "both": "both have %s",
    "either": "either has %s",
    "diff": "only one has %s",
    "a": "A has %s",
    "b": "B has %s",
}


class PairBooleanizer(BaseEstimator):
    """Bits for comparing two items (two documents, two records) without the model seeing which came first.

    Each item is turned into word bits (or any 0/1 vector). For every feature the pair gets
    ``both`` (present in both), ``either`` (present in at least one), ``diff`` (present in exactly one),
    and/or ``a`` / ``b`` (present in the first / second item; these depend on the order).

    The default modes ``("both", "diff")`` are symmetric, so swapping A and B gives the same bits, and the
    "both" bits carry the overlap that a pair task needs.

    base: how a single item becomes bits. None builds a :class:`TextBooleanizer`; an object with
        ``fit``/``transform`` is used as it is (fit on A and B together); ``False`` means the inputs are already
        0/1 matrices.
    """

    def __init__(self, base=None, mode=("both", "diff")):
        self.base = base
        self.mode = mode

    def _modes(self):
        modes = (self.mode,) if isinstance(self.mode, str) else tuple(self.mode)
        bad = [m for m in modes if m not in _PAIR_NAMES]
        if bad or not modes:
            raise ValueError("mode must be one or more of %s" % ", ".join(sorted(_PAIR_NAMES)))
        return modes

    def _single(self, A, B, fit):
        if self.base is False:
            A, B = np.asarray(A), np.asarray(B)
            if A.shape != B.shape or A.ndim != 2:
                raise ValueError("A and B must be 2-dimensional with the same shape")
            if fit:
                self.base_ = None
                self.names_ = np.asarray(["x%d" % j for j in range(A.shape[1])], dtype=object)
            return A.astype(bool), B.astype(bool)
        if fit:
            base = TextBooleanizer() if self.base is None else self.base
            if len(A) != len(B):
                raise ValueError("A and B must have the same number of items")
            base.fit(list(A) + list(B) if not isinstance(A, np.ndarray) else np.concatenate([A, B]))
            self.base_ = base
            self.names_ = np.asarray(base.get_feature_names_out(), dtype=object)
        return self.base_.transform(A).astype(bool), self.base_.transform(B).astype(bool)

    def fit(self, A, B):
        self._modes()
        self._single(A, B, fit=True)
        return self

    def transform(self, A, B):
        if not hasattr(self, "names_"):
            raise RuntimeError("call fit first")
        a, b = self._single(A, B, fit=False)
        blocks = {"both": a & b, "either": a | b, "diff": a ^ b, "a": a, "b": b}
        return np.concatenate([blocks[m] for m in self._modes()], axis=1).astype(np.uint8)

    def fit_transform(self, A, B):
        return self.fit(A, B).transform(A, B)

    def get_feature_names_out(self, input_features=None):
        return np.asarray([_PAIR_NAMES[m] % n for m in self._modes() for n in self.names_], dtype=object)

    def get_literal_names_out(self):
        names = [str(n) for n in self.get_feature_names_out()]
        return names + ["NOT " + n for n in names]
