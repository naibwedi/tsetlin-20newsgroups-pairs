import numpy as np

from ._compat import BaseEstimator, TransformerMixin

class QuantileBooleanizer:
    """Thermometer-encode numeric columns: one bit per quantile threshold (all columns get n_bins bits).

    Kept for simple numeric arrays; :class:`Booleanizer` handles mixed, categorical and missing data.
    """

    def __init__(self, n_bins=8):
        self.n_bins = n_bins
        self.thresholds_ = None

    def fit(self, X):
        X = np.asarray(X, dtype=np.float64)
        qs = np.linspace(0, 1, self.n_bins + 2)[1:-1]
        self.thresholds_ = np.quantile(X, qs, axis=0).T  # (n_cols, n_bins)
        return self

    def transform(self, X):
        X = np.asarray(X, dtype=np.float64)
        bits = X[:, :, None] > self.thresholds_[None, :, :]
        return bits.reshape(X.shape[0], -1).astype(np.uint8)

    def fit_transform(self, X):
        return self.fit(X).transform(X)


def _columns(X):
    """(names, list of 1-D column arrays) from a pandas DataFrame, a 2-D array or a list of rows."""
    if hasattr(X, "columns") and hasattr(X, "iloc"):  # pandas, without importing it
        return [str(c) for c in X.columns], [X.iloc[:, j].to_numpy() for j in range(X.shape[1])]
    X = np.asarray(X, dtype=object if not isinstance(X, np.ndarray) else None)
    if X.ndim != 2:
        raise ValueError("X must be 2-dimensional")
    return ["x%d" % j for j in range(X.shape[1])], [X[:, j] for j in range(X.shape[1])]


def _is_numeric(col):
    if col.dtype.kind in "iuf":
        return True
    if col.dtype.kind != "O":
        return False
    try:
        col.astype(np.float64)
        return True
    except (TypeError, ValueError):
        return False


def _fmt(v):
    return ("%.6g" % v) if isinstance(v, (float, np.floating)) else str(v)


class Booleanizer(TransformerMixin, BaseEstimator):
    """Turn a table with numeric, categorical and missing values into the 0/1 matrix a Tsetlin Machine needs.

    Numeric columns get one bit per distinct quantile threshold (``value > threshold``, a thermometer code).
    Other columns (strings, booleans, pandas categories) get one bit per category seen in ``fit``, up to
    ``max_categories`` of the most frequent; rarer or unseen categories set none of the column's bits.
    Missing values (``None``, NaN) set none of their column's bits, so they read as "not above any threshold" and
    "not any known category": a positive literal never matches a missing value, a negated one always does.

    n_bins: thresholds per numeric column (fewer when the column has fewer distinct values).
    categorical: column names or indices to treat as categorical even if numeric (e.g. integer codes);
        ``"auto"`` treats non-numeric columns as categorical.
    max_categories: cap on bits per categorical column.

    After ``fit``: ``get_feature_names_out()`` names every output bit, and ``get_literal_names_out()`` names
    both the bits and their negations (useful for ``rules``), e.g. ``age > 37`` / ``age <= 37``.
    """

    def __init__(self, n_bins=8, categorical="auto", max_categories=50):
        if n_bins < 1:
            raise ValueError("n_bins must be >= 1")
        if max_categories < 1:
            raise ValueError("max_categories must be >= 1")
        self.n_bins = n_bins
        self.categorical = categorical
        self.max_categories = max_categories

    def fit(self, X, y=None):
        names, cols = _columns(X)
        forced = set() if self.categorical == "auto" else set(self.categorical)
        self.feature_names_in_ = np.array(names, dtype=object)
        self.n_features_in_ = len(names)
        self.encoders_ = []
        qs = np.linspace(0, 1, self.n_bins + 2)[1:-1]
        for j, (name, col) in enumerate(zip(names, cols)):
            if j not in forced and name not in forced and _is_numeric(col):
                v = col.astype(np.float64)
                v = v[~np.isnan(v)]
                thr = np.unique(np.quantile(v, qs)) if len(v) else np.array([])
                thr = thr[thr < v.max()] if len(v) else thr  # a threshold at the maximum is never exceeded
                self.encoders_.append(("num", thr))
            else:
                keys = np.array([_key(x) for x in col], dtype=object)
                keys = keys[keys != None]  # noqa: E711 (elementwise)
                cats, counts = np.unique(keys.astype(str), return_counts=True) if len(keys) else ([], [])
                order = np.argsort(-np.asarray(counts), kind="stable")[: self.max_categories]
                self.encoders_.append(("cat", np.sort(np.asarray(cats, dtype=object)[order])))
        return self

    def transform(self, X):
        self._check_fitted()
        names, cols = _columns(X)
        if len(cols) != self.n_features_in_:
            raise ValueError("X has %d columns, expected %d" % (len(cols), self.n_features_in_))
        parts = []
        for (kind, enc), col in zip(self.encoders_, cols):
            if kind == "num":
                v = col.astype(np.float64)
                with np.errstate(invalid="ignore"):
                    parts.append(v[:, None] > enc[None, :])  # NaN > t is False
            else:
                keys = np.array([("" if _key(x) is None else str(_key(x))) for x in col], dtype=object)
                parts.append(keys[:, None] == enc[None, :])
        n = len(cols[0]) if cols else 0
        out = np.concatenate(parts, axis=1) if parts else np.zeros((n, 0), dtype=bool)
        return out.astype(np.uint8)

    def fit_transform(self, X, y=None):
        return self.fit(X).transform(X)

    def get_feature_names_out(self, input_features=None):
        return np.array(self._names(negated=False), dtype=object)

    def get_literal_names_out(self):
        """Names for the 2 * n_bits literals in bittm's order: every bit, then every bit negated."""
        return np.array(self._names(negated=False) + self._names(negated=True), dtype=object)

    @property
    def n_bits_(self):
        self._check_fitted()
        return sum(len(enc) for _, enc in self.encoders_)

    def _names(self, negated):
        self._check_fitted()
        out = []
        for name, (kind, enc) in zip(self.feature_names_in_, self.encoders_):
            op = ("<=" if negated else ">") if kind == "num" else ("!=" if negated else "=")
            out += ["%s %s %s" % (name, op, _fmt(t)) for t in enc]
        return out

    def _check_fitted(self):
        if not hasattr(self, "encoders_"):
            raise RuntimeError("call fit first")


def _key(x):
    """Category key: None for missing values (None or NaN), otherwise the value itself."""
    if x is None:
        return None
    try:
        if x != x:  # NaN
            return None
    except (TypeError, ValueError):
        pass
    return x
