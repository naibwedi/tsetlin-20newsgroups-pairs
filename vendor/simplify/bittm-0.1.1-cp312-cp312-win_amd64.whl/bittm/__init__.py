"""bittm: fast, interpretable Tsetlin Machines with bit-packed training and inference."""
from ._version import __version__
from .booleanize import Booleanizer, QuantileBooleanizer
from .calibration import VoteCalibrator
from .features import PairBooleanizer, TextBooleanizer
from .metrics import best_threshold, evaluate, roc_auc
from .model import PackedModel, Rule, load
from .tm import CoalescedTsetlinMachine, TsetlinMachine

__all__ = ["Booleanizer", "CoalescedTsetlinMachine", "PackedModel", "PairBooleanizer", "QuantileBooleanizer", "Rule",
           "TextBooleanizer", "TsetlinMachine", "VoteCalibrator", "__version__", "best_threshold", "evaluate", "load",
           "roc_auc"]
